/* ============================================================
   YYLMZXC 离线导航站 · 通用纯函数
   纯计算，不依赖 DOM、不依赖全局状态，可单独复用与测试。
   ============================================================ */
window.Nav = window.Nav || {};
(function (Nav) {
  'use strict';

  var PALETTE = ['#5b9dff', '#7c5cff', '#ff7a59', '#37d67a', '#e84393', '#00b8d9', '#f5a524', '#8e6bff', '#ff5c6c', '#2ecc71'];

  // 默认头像：没有自定义头像（或自定义头像加载失败）时使用，路径相对页面根目录
  var DEFAULT_AVATAR = 'res/img.png';

  function clone(o) {
    return JSON.parse(JSON.stringify(o));
  }

  // 生成一个 id。除了时间戳与随机串，再串一个自增序号：
  // 批量导入时（几千条书签在同一毫秒内生成）随机串会撞车，而 id 是数据库主键，
  // 一条重复就让整笔写入回滚（表现为「导入后数据没保存」）。自增序号保证同一页面会话内绝不重复。
  var uidSeq = 0;
  function uid(prefix) {
    uidSeq = (uidSeq + 1) % 1679616;                     // 36^4，回绕概率可忽略
    var rand = Math.random().toString(36).slice(2, 6);
    while (rand.length < 4) rand += '0';                 // 极小概率随机串不足 4 位时补齐
    return (prefix || 'x') + Date.now().toString(36) + uidSeq.toString(36) + rand;
  }

  function hostOf(url) {
    try { return new URL(url).hostname.replace(/^www\./, ''); }
    catch (e) { return ''; }
  }

  function normalizeUrl(u) {
    u = String(u || '').trim();
    if (!u) return '';
    if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(u)) u = 'https://' + u;
    return u;
  }

  function faviconOf(link) {
    if (link.favicon) return link.favicon;
    if (link.icon && /^https?:/.test(link.icon)) return link.icon;
    // 不依赖任何第三方图标聚合服务，直接取站点自身的 favicon；失败时由渲染层回退为首字母头像。
    try { return new URL(normalizeUrl(link.url)).origin + '/favicon.ico'; }
    catch (e) { return ''; }
  }

  // 快捷链接允许两种写法：纯 URL 字符串，或 { url, favicon }（与书签字段保持一致）
  function profileLink(u) {
    if (typeof u === 'string') return { url: u, favicon: '' };
    if (!u) return { url: '', favicon: '' };
    return { url: u.url || '', favicon: u.favicon || '' };
  }

  function colorFor(seed) {
    var s = String(seed || ''), n = 0;
    for (var i = 0; i < s.length; i++) n = (n * 31 + s.charCodeAt(i)) >>> 0;
    return PALETTE[n % PALETTE.length];
  }

  function letterAvatar(text, seed) {
    var ch = (String(text || '?').trim()[0] || '?').toUpperCase();
    var bg = colorFor(seed || text);
    var svgStr = "<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64'>" +
      "<rect width='64' height='64' rx='16' fill='" + bg + "'/>" +
      "<text x='32' y='42' font-size='32' font-family='Arial' font-weight='bold' fill='#fff' text-anchor='middle'>" + ch + "</text></svg>";
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svgStr);
  }

  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function matchLink(link, q) {
    if (!q) return true;
    return (String(link.title || '').toLowerCase().indexOf(q) >= 0) ||
           (String(link.url || '').toLowerCase().indexOf(q) >= 0);
  }

  Nav.util = {
    DEFAULT_AVATAR: DEFAULT_AVATAR,
    clone: clone,
    uid: uid,
    hostOf: hostOf,
    normalizeUrl: normalizeUrl,
    faviconOf: faviconOf,
    profileLink: profileLink,
    colorFor: colorFor,
    letterAvatar: letterAvatar,
    escapeHtml: escapeHtml,
    matchLink: matchLink
  };
})(window.Nav);
